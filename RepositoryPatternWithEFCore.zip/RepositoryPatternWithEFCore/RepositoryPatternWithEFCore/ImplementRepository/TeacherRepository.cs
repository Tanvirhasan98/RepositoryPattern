﻿namespace RepositoryPatternWithEFCore.ImplementRepository
{
    public class TeacherRepository
    {
    }
}
