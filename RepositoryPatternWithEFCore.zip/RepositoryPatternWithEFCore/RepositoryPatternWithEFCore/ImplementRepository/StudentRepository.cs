﻿using Microsoft.AspNetCore.Mvc;
using RepositoryPatternWithEFCore.Data;
using RepositoryPatternWithEFCore.Model;
using RepositoryPatternWithEFCore.Repository;

namespace RepositoryPatternWithEFCore.ImplementRepository
{
    public class StudentRepository : IStudentRepository
    {
        private readonly ManyToManyContext _context;

        public StudentRepository(ManyToManyContext context)
        {
            _context = context;

        }
        public async Task<ActionResult<Student>> GetAll(int StudentId)
        {
            var students = await _context.Students.FindAsync(StudentId);
            return students;
        }
    }
}
