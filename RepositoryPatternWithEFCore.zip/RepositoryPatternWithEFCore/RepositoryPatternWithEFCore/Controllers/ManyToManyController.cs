﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RepositoryPatternWithEFCore.Data;
using RepositoryPatternWithEFCore.Model;
using RepositoryPatternWithEFCore.Repository;

namespace RepositoryPatternWithEFCore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ManyToManyController : ControllerBase
    {
        private readonly ManyToManyContext _db;
        private readonly IStudentRepository _context;
       

        public ManyToManyController(ManyToManyContext db, IStudentRepository context)
        {
           
            _db = db;
            _context = context;

        }
        [HttpGet]
        public async Task<ActionResult<List<Student>>> Get(int studentId)
        {
            var students = await _db. Students
                .Include(a => a.Teachers)
                .Where(c => c.StudentId == studentId)
                .ToListAsync();

            return students;
        }
        [HttpGet("GetById")]
        public async Task<ActionResult<Student>> GetById(int Id)
        {
            return await _context.GetAll(Id);
        }

 
        }

   }
 

