﻿namespace RepositoryPatternWithEFCore.Model
{
    public class Teacher
    {
        public int TeacherId { get; set; }
        public string TeacherName { get; set; } = String.Empty;
        public string TeacherAddress { get; set; } = String.Empty;


        // public IList<StudentTeacher> StudentTeachers{ get; set; }
        public virtual ICollection<Student> Students { get; set; }
    }
}
