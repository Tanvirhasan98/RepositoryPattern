﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RepositoryPatternWithEFCore.Migrations
{
    public partial class CoreMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
