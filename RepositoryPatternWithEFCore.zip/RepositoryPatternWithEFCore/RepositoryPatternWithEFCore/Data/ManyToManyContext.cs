﻿using Microsoft.EntityFrameworkCore;
using RepositoryPatternWithEFCore.Model;

namespace RepositoryPatternWithEFCore.Data
{
    public class ManyToManyContext:DbContext
    {

        public ManyToManyContext(DbContextOptions<ManyToManyContext> options):base(options)
        {

        }
        public DbSet<Student> Students { get; set; }
        public DbSet<Teacher> Teachers { get; set; }
        public DbSet<StudentTeacher> StudentTeachers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelbuilder)
        {

            modelbuilder.Entity<Teacher>()
                .HasMany(t => t.Students)
                .WithMany(s => s.Teachers)
                .UsingEntity(j => j.ToTable("StudentTeacher"));


        }

    }
}
