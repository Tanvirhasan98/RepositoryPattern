﻿using Microsoft.AspNetCore.Mvc;
using RepositoryPatternWithEFCore.Model;

namespace RepositoryPatternWithEFCore.Repository
{
    public interface IStudentRepository
    {
        public Task<ActionResult<Student>> GetAll(int StudentId);
    }
}
