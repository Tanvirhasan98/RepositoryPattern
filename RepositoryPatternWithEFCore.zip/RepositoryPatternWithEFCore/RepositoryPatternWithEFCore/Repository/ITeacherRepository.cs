﻿namespace RepositoryPatternWithEFCore.Repository
{
    public interface ITeacherRepository
    {
    }
}
